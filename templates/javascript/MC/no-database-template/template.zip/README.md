# Hati Model Controller Javascript Template

This template was generated using [Hati](https://github.com/wllfaria/Hati) CLI.

## Template Definition

This is a Model Controller template, which uses the MVC (Model View Controller) to make an express API, but for this project. the View (V) would be a webapp or other application.
