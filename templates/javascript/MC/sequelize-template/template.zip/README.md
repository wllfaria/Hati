# Hati Sequelize Model Controller Javascript Template

This template was generated using [Hati](https://github.com/wllfaria/Hati) CLI.

## Template Definition

This is a Model Controller template
