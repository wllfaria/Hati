# Hati Package By Feature Javascript Template

This template was generated using [Hati](https://github.com/wllfaria/Hati) CLI.

## Template Definition

This is a Package by Feature template, which means that every feature must be separated from any other, as if each feature was a small product ready to deliver.
